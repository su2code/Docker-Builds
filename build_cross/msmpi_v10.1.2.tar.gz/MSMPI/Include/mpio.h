// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

#error do not include mpio.h, use mpi.h

